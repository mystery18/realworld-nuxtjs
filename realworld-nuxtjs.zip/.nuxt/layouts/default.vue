<template>
  <Nuxt />
</template>
